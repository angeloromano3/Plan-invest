public class Usuario {

    private int idUsuario;
    private String nome;
    private String email;

    public void cadastrarUsuario() {
        System.out.println("Executando método cadastrar usuário");
    }

    public void consultarUsuario() {
        System.out.println("Consultando dados do usuário");
    }

}
