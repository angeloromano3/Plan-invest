public class Login {

    private String usuario;
    private String senha;

    // Construtor vazio
    public Login() {
    }

    // Construtor com parâmetros
    public Login(String usuario, String senha) {
        this.usuario = usuario;
        this.senha = senha;
    }

    public void realizarLogin() {
        System.out.println("Fazendo o Login");
    }

    public void validarUsuario() {
        System.out.println("Validando usuário e senha");
    }

}