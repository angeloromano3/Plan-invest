public class Main {

    public static void main(String[] args) {

        System.out.println("Sistema Plan+Invest iniciado");

    }

}