public class Transacao {

    private int idTransacao;
    private double valor;
    private String tipo;

    public void registrarTransacao() {
        System.out.println("Registrando transação financeira");
    }

}