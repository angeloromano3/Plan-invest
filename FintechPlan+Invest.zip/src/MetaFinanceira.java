public class MetaFinanceira {

    private int idMeta;
    private double valorMeta;
    private String descricao;

    public void criarMeta() {
        System.out.println("Criando meta financeira");
    }

    public void acompanharMeta() {
        System.out.println("Acompanhando progresso da meta");
    }

}