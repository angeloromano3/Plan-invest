public class Conta {

    private int idConta;
    private double saldo;
    private String tipoConta;

    public void consultarSaldo() {
        System.out.println("Consultando saldo da conta");
    }

    public void atualizarSaldo() {
        System.out.println("Atualizando saldo da conta");
    }

}